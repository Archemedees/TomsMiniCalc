﻿Public Class MiniCalc


    Public Declare Function RegisterHotKey Lib "user32" (ByVal hwnd As IntPtr, ByVal id As Integer, ByVal fsModifiers As Integer, ByVal vk As Integer) As Integer
    Public Declare Function UnregisterHotKey Lib "user32" (ByVal hwnd As IntPtr, ByVal id As Integer) As Integer
    Public Const WM_HOTKEY As Integer = &H312
    Private Declare Sub keybd_event Lib "user32" (ByVal bVk As Byte, ByVal bScan As Byte, ByVal dwFlags As IntPtr, ByVal dwExtraInfo As IntPtr)



    Private valHolder3 As Double
    Private keyboardcode As Integer = 81


    Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)



        If m.Msg = WM_HOTKEY Then
            Debug.WriteLine(m.Msg.ToString & ":" & m.WParam.ToString & ":" & m.LParam.ToString)
            SendKeys.Send("^(c)")

            If IsNumeric(Clipboard.GetText) Then
                valHolder3 = Clipboard.GetText
                valHolder3 = valHolder3 / 25.4
                valHolder3 = Math.Ceiling(valHolder3 * 100) / 100D
                Clipboard.SetText(valHolder3)
                SendKeys.Send("^(v)")
            Else : Exit Sub
            End If

        End If
        MyBase.WndProc(m)

    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Call UnregisterHotKey(Me.Handle, 9)
    End Sub

    Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Call RegisterHotKey(Me.Handle.ToInt32, 0, &H2, keyboardcode)

    End Sub





    'variables to hold operands
    Private valHolder1 As Double
    Private valHolder2 As Double
    'Varible to hold temporary values
    Private tmpValue As Double
    'True if "." is use else false
    Private hasDecimal As Boolean
    Private inputStatus As Boolean
    Private clearText As Boolean
    'variable to hold Operater
    Private calcFunc As String



#Region "DragNDrop"
    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer

    Private Sub OverlayText_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown, TableLayoutPanel1.MouseDown

        drag = True 'Sets the variable drag to true.
        mousex = Windows.Forms.Cursor.Position.X - Me.Left 'Sets variable mousex
        mousey = Windows.Forms.Cursor.Position.Y - Me.Top 'Sets variable mousey
    End Sub

    Private Sub OverlayText_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove, TableLayoutPanel1.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Me.Top = Windows.Forms.Cursor.Position.Y - mousey
            Me.Left = Windows.Forms.Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub OverlayText_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseUp, TableLayoutPanel1.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub


#End Region



    Private Sub CalcTxtBx_KeyDown(sender As Object, e As KeyEventArgs) Handles CalcTxtBx.KeyDown

        If e.KeyCode.Equals(Keys.Delete) Then
            'Empty the text in the input box
            CalcTxtBx.Text = String.Empty
            'Clear out both temp values
            valHolder1 = 0
            valHolder2 = 0
            'Set the calc switch to empty
            calcFunc = String.Empty
            'Toggle the hasDecimal flag
            hasDecimal = False
        End If


        If e.KeyCode.Equals(Keys.Back) Then
            'Declare locals needed
            Dim str As String
            Dim loc As Integer
            'Make sure the text length is > 1
            If CalcTxtBx.Text.Length > 0 Then
                'Get the next to last character
                str = CalcTxtBx.Text.Chars(CalcTxtBx.Text.Length - 1)
                'Check if its a decimal
                If str = "." Then
                    'If it is toggle the hasDecimal flag
                    hasDecimal = False
                End If
                'Get the length of the string
                loc = CalcTxtBx.Text.Length
                'Remove the last character, incrementing by 1
                CalcTxtBx.Text = CalcTxtBx.Text.Remove(loc - 1, 1)
            End If
        End If

        If e.KeyCode.Equals(Keys.Enter) Then
            'Make sure theres a value in the input box
            'And that our temp value isnt 0
            If CalcTxtBx.Text.Length <> 0 AndAlso valHolder1 <> 0 Then
                'Call the calculate totals method
                CalculateTotals()
                'Clear the calcFunction value
                calcFunc = String.Empty
                'Toggle the decimal flag
                hasDecimal = False
            End If
        End If


        '--------------------------------------------------------------
        '---------------------OPERATORS--------------------------------
        '--------------------------------------------------------------
        If e.KeyCode.Equals(Keys.Add) Then
            'Make sure out input box has a value RUN CALCULATIONS
            If CalcTxtBx.Text.Length <> 0 Then
                'Check the value of our function flag
                If calcFunc = String.Empty Then 'Flag is empty
                    'Assign the value in our input
                    'box to our holder
                    valHolder1 = CType(CalcTxtBx.Text, Double)
                    'Empty the input box
                    CalcTxtBx.Text = String.Empty
                Else 'Flag isnt empty
                    'Call our calculate totals method
                    CalculateTotals()
                End If
                'Assign a value to our calc function flag
                calcFunc = "Add"
                'Toggle the decimal flag
                hasDecimal = False
            End If
        End If

        If e.KeyCode.Equals(Keys.Subtract) Then
            If CalcTxtBx.Text.Length <> 0 Then
                If calcFunc = String.Empty Then
                    valHolder1 = CType(CalcTxtBx.Text, Double)
                    CalcTxtBx.Text = String.Empty
                Else
                    CalculateTotals()
                End If
                calcFunc = "Subtract"
                hasDecimal = False
            End If
        End If

        If e.KeyCode.Equals(Keys.Multiply) Then
            If CalcTxtBx.Text.Length <> 0 Then
                If calcFunc = String.Empty Then
                    valHolder1 = CType(CalcTxtBx.Text, Double)
                    CalcTxtBx.Text = String.Empty
                Else
                    CalculateTotals()
                End If
                calcFunc = "Multiply"
                hasDecimal = False
            End If
        End If

        If e.KeyCode.Equals(Keys.Divide) Then
            If CalcTxtBx.Text.Length <> 0 Then
                If calcFunc = String.Empty Then
                    valHolder1 = CType(CalcTxtBx.Text, Double)
                    CalcTxtBx.Text = String.Empty
                Else
                    CalculateTotals()
                End If
                calcFunc = "Divide"
                hasDecimal = False
            End If
        End If
        '--------------------------------------------------------------
        '---------------------OPERATORS END----------------------------
        '--------------------------------------------------------------

        If e.KeyCode.Equals(Keys.Decimal) Then
            'Check for input status (we want true)
            If inputStatus Then
                'Check if it already has a decimal (if it does then do nothing)
                If Not hasDecimal Then
                    'Two if statements have been nullified by moving the Else statement to the same level as the first If
                    'Check to make sure the length is > than 1, although inputStatus = True already says so
                    'Dont want user to add decimal as first character
                    'If txtInput.Text.Length > 1 Then
                    'Make sure 0 isnt the first number, although this should not be possible
                    'If Not txtInput.Text = "0" Then
                    'It met all our requirements so add the decimal
                    CalcTxtBx.Text += "."
                    'Toggle the flag hasDecimal to true (only 1 decimal per calculation)
                    hasDecimal = True
                    'End If
                    'The Else statement was here originally
                    'This is an example of a logical error
                End If
                'End If
            Else
                'Since the length isnt > 1
                'make the text 0.
                CalcTxtBx.Text = "0."
                'The following three lines have been added by me
                'Toggle the flags hasDecimal and inputStatus to True
                hasDecimal = True
                inputStatus = True
            End If
        End If


        If e.KeyCode.Equals(Keys.NumPad0) Then
            'Check the input status
            If inputStatus Then 'If true
                'Now check to make sure our
                'input box has a value
                If CalcTxtBx.Text.Length >= 1 Then
                    'Add our zero
                    CalcTxtBx.Text += "0"
                End If
            End If

        ElseIf e.KeyCode.Equals(Keys.NumPad1) Then
            'Check the inputStatus
            If inputStatus Then 'Its True
                'Append values to the value in the input box
                CalcTxtBx.Text += "1"
            Else   'Value is False
                'Set the value to the value of the button
                CalcTxtBx.Text = "1"
                'Toggle inputStatus to True
                inputStatus = True
            End If

        ElseIf e.KeyCode.Equals(Keys.NumPad2) Then

            If inputStatus Then
                CalcTxtBx.Text += "2"
            Else
                CalcTxtBx.Text = "2"
                inputStatus = True
            End If


        ElseIf e.KeyCode.Equals(Keys.NumPad3) Then

            If inputStatus Then
                CalcTxtBx.Text += "3"
            Else
                CalcTxtBx.Text = "3"
                inputStatus = True
            End If


        ElseIf e.KeyCode.Equals(Keys.NumPad4) Then

            If inputStatus Then
                CalcTxtBx.Text += "4"
            Else
                CalcTxtBx.Text = "4"
                inputStatus = True
            End If


        ElseIf e.KeyCode.Equals(Keys.NumPad5) Then

            If inputStatus Then
                CalcTxtBx.Text += "5"
            Else
                CalcTxtBx.Text = "5"
                inputStatus = True
            End If


        ElseIf e.KeyCode.Equals(Keys.NumPad6) Then

            If inputStatus Then
                CalcTxtBx.Text += "6"
            Else
                CalcTxtBx.Text = "6"
                inputStatus = True
            End If


        ElseIf e.KeyCode.Equals(Keys.NumPad7) Then

            If inputStatus Then
                CalcTxtBx.Text += "7"
            Else
                CalcTxtBx.Text = "7"
                inputStatus = True
            End If


        ElseIf e.KeyCode.Equals(Keys.NumPad8) Then

            If inputStatus Then
                CalcTxtBx.Text += "8"
            Else
                CalcTxtBx.Text = "8"
                inputStatus = True
            End If


        ElseIf e.KeyCode.Equals(Keys.NumPad9) Then

            If inputStatus Then
                CalcTxtBx.Text += "9"
            Else
                CalcTxtBx.Text = "9"
                inputStatus = True
            End If

        ElseIf e.Modifiers = Keys.Control AndAlso e.KeyCode = Keys.V Then

            Using box As New RichTextBox
                box.SelectAll()
                box.SelectedRtf = Clipboard.GetText(TextDataFormat.Rtf)
                box.SelectAll()
                box.SelectionBackColor = Color.White
                box.SelectionColor = Color.Black


                If inputStatus Then
                    'CalcTxtBx.Text += box.SelectedRtf
                    CalcTxtBx.Text += Clipboard.GetText
                Else
                    'CalcTxtBx.Text = box.SelectedRtf
                    CalcTxtBx.Text = Clipboard.GetText
                    inputStatus = True
                End If
            End Using

            e.Handled = True
        End If


    End Sub

    Private Sub CalculateTotals()
        valHolder2 = CType(CalcTxtBx.Text, Double)
        Select Case calcFunc
            Case "Add"
                valHolder1 = valHolder1 + valHolder2
            Case "Subtract"
                valHolder1 = valHolder1 - valHolder2
            Case "Divide"
                valHolder1 = valHolder1 / valHolder2
            Case "Multiply"
                valHolder1 = valHolder1 * valHolder2
            Case "PowerOf"
                valHolder1 = System.Math.Pow(valHolder1, valHolder2)
        End Select
        CalcTxtBx.Text = CType(valHolder1, String)
        inputStatus = False
    End Sub

    Private Sub CalcTxtBx_TextChanged(sender As Object, e As EventArgs) Handles CalcTxtBx.TextChanged
        MMtoFtTxtBx.Text = Val(CalcTxtBx.Text) / 304.8
        INtoFtTxtBx.Text = Val(CalcTxtBx.Text) / 12
        MMtoINTxtBx.Text = Val(CalcTxtBx.Text) / 25.4
        FTtoINTxtBx.Text = Val(CalcTxtBx.Text) * 12
        FTtoMMTxtBx.Text = Val(CalcTxtBx.Text) * 304.8
        INtoMMTxtBx.Text = Val(CalcTxtBx.Text) * 25.4
    End Sub

    Private Sub ClearBtn_Click(sender As Object, e As EventArgs) Handles ClearBtn.Click
        'Empty the text in the input box
        CalcTxtBx.Text = String.Empty
        'Clear out both temp values
        valHolder1 = 0
        valHolder2 = 0

        'Set the calc switch to empty
        calcFunc = String.Empty
        'Toggle the hasDecimal flag
        hasDecimal = False

        CalcTxtBx.Select()
    End Sub

    Private Sub AlwaysOnTopToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AlwaysOnTopToolStripMenuItem.Click
        If AlwaysOnTopToolStripMenuItem.Checked = True Then
            Me.TopMost = True
        Else
            Me.TopMost = False

        End If

    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        AboutBox1.Show()

    End Sub
End Class


