﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MiniCalc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MiniCalc))
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AlwaysOnTopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExgRtText = New System.Windows.Forms.TextBox()
        Me.MMtoFtTxtBx = New System.Windows.Forms.TextBox()
        Me.MMtoFtLabel = New System.Windows.Forms.Label()
        Me.INtoFtTxtBx = New System.Windows.Forms.TextBox()
        Me.FTtoINTxtBx = New System.Windows.Forms.TextBox()
        Me.FtTOIN = New System.Windows.Forms.Label()
        Me.InchestoFtLabel = New System.Windows.Forms.Label()
        Me.MMtoINTxtBx = New System.Windows.Forms.TextBox()
        Me.MMtoInchesLabel = New System.Windows.Forms.Label()
        Me.INtoMMLabel = New System.Windows.Forms.Label()
        Me.INtoMMTxtBx = New System.Windows.Forms.TextBox()
        Me.FtToMM = New System.Windows.Forms.Label()
        Me.FTtoMMTxtBx = New System.Windows.Forms.TextBox()
        Me.ClearBtn = New System.Windows.Forms.Button()
        Me.USDText = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CalcTxtBx = New System.Windows.Forms.TextBox()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 7
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TableLayoutPanel1.Controls.Add(Me.ExgRtText, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.MMtoFtTxtBx, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.MMtoFtLabel, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.INtoFtTxtBx, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.FTtoINTxtBx, 4, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.FtTOIN, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.InchestoFtLabel, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.MMtoINTxtBx, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.MMtoInchesLabel, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.INtoMMLabel, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.INtoMMTxtBx, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.FtToMM, 4, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.FTtoMMTxtBx, 4, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.ClearBtn, 4, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.USDText, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 4)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(5, 29)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 6
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(196, 118)
        Me.TableLayoutPanel1.TabIndex = 18
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AlwaysOnTopToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(155, 48)
        '
        'AlwaysOnTopToolStripMenuItem
        '
        Me.AlwaysOnTopToolStripMenuItem.CheckOnClick = True
        Me.AlwaysOnTopToolStripMenuItem.Name = "AlwaysOnTopToolStripMenuItem"
        Me.AlwaysOnTopToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.AlwaysOnTopToolStripMenuItem.Text = "Always On Top"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'ExgRtText
        '
        Me.ExgRtText.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExgRtText.Location = New System.Drawing.Point(3, 94)
        Me.ExgRtText.Name = "ExgRtText"
        Me.ExgRtText.Size = New System.Drawing.Size(58, 20)
        Me.ExgRtText.TabIndex = 20
        '
        'MMtoFtTxtBx
        '
        Me.MMtoFtTxtBx.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MMtoFtTxtBx.Location = New System.Drawing.Point(3, 16)
        Me.MMtoFtTxtBx.Name = "MMtoFtTxtBx"
        Me.MMtoFtTxtBx.Size = New System.Drawing.Size(58, 20)
        Me.MMtoFtTxtBx.TabIndex = 6
        '
        'MMtoFtLabel
        '
        Me.MMtoFtLabel.AutoSize = True
        Me.MMtoFtLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MMtoFtLabel.Location = New System.Drawing.Point(3, 0)
        Me.MMtoFtLabel.Name = "MMtoFtLabel"
        Me.MMtoFtLabel.Size = New System.Drawing.Size(59, 13)
        Me.MMtoFtLabel.TabIndex = 1
        Me.MMtoFtLabel.Text = "MM TO FT"
        '
        'INtoFtTxtBx
        '
        Me.INtoFtTxtBx.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.INtoFtTxtBx.Location = New System.Drawing.Point(68, 16)
        Me.INtoFtTxtBx.Name = "INtoFtTxtBx"
        Me.INtoFtTxtBx.Size = New System.Drawing.Size(58, 20)
        Me.INtoFtTxtBx.TabIndex = 7
        '
        'FTtoINTxtBx
        '
        Me.FTtoINTxtBx.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FTtoINTxtBx.Location = New System.Drawing.Point(132, 16)
        Me.FTtoINTxtBx.Name = "FTtoINTxtBx"
        Me.FTtoINTxtBx.Size = New System.Drawing.Size(58, 20)
        Me.FTtoINTxtBx.TabIndex = 9
        '
        'FtTOIN
        '
        Me.FtTOIN.AutoSize = True
        Me.FtTOIN.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FtTOIN.Location = New System.Drawing.Point(132, 0)
        Me.FtTOIN.Name = "FtTOIN"
        Me.FtTOIN.Size = New System.Drawing.Size(52, 13)
        Me.FtTOIN.TabIndex = 4
        Me.FtTOIN.Text = "FT TO IN"
        '
        'InchestoFtLabel
        '
        Me.InchestoFtLabel.AutoSize = True
        Me.InchestoFtLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InchestoFtLabel.Location = New System.Drawing.Point(68, 0)
        Me.InchestoFtLabel.Name = "InchestoFtLabel"
        Me.InchestoFtLabel.Size = New System.Drawing.Size(52, 13)
        Me.InchestoFtLabel.TabIndex = 2
        Me.InchestoFtLabel.Text = "IN TO FT"
        '
        'MMtoINTxtBx
        '
        Me.MMtoINTxtBx.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MMtoINTxtBx.Location = New System.Drawing.Point(3, 55)
        Me.MMtoINTxtBx.Name = "MMtoINTxtBx"
        Me.MMtoINTxtBx.Size = New System.Drawing.Size(58, 20)
        Me.MMtoINTxtBx.TabIndex = 8
        '
        'MMtoInchesLabel
        '
        Me.MMtoInchesLabel.AutoSize = True
        Me.MMtoInchesLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MMtoInchesLabel.Location = New System.Drawing.Point(3, 39)
        Me.MMtoInchesLabel.Name = "MMtoInchesLabel"
        Me.MMtoInchesLabel.Size = New System.Drawing.Size(57, 13)
        Me.MMtoInchesLabel.TabIndex = 3
        Me.MMtoInchesLabel.Text = "MM TO IN"
        '
        'INtoMMLabel
        '
        Me.INtoMMLabel.AutoSize = True
        Me.INtoMMLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.INtoMMLabel.Location = New System.Drawing.Point(68, 39)
        Me.INtoMMLabel.Name = "INtoMMLabel"
        Me.INtoMMLabel.Size = New System.Drawing.Size(57, 13)
        Me.INtoMMLabel.TabIndex = 12
        Me.INtoMMLabel.Text = "IN TO MM"
        '
        'INtoMMTxtBx
        '
        Me.INtoMMTxtBx.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.INtoMMTxtBx.Location = New System.Drawing.Point(68, 55)
        Me.INtoMMTxtBx.Name = "INtoMMTxtBx"
        Me.INtoMMTxtBx.Size = New System.Drawing.Size(58, 20)
        Me.INtoMMTxtBx.TabIndex = 13
        '
        'FtToMM
        '
        Me.FtToMM.AutoSize = True
        Me.FtToMM.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FtToMM.Location = New System.Drawing.Point(132, 39)
        Me.FtToMM.Name = "FtToMM"
        Me.FtToMM.Size = New System.Drawing.Size(59, 13)
        Me.FtToMM.TabIndex = 5
        Me.FtToMM.Text = "FT TO MM"
        '
        'FTtoMMTxtBx
        '
        Me.FTtoMMTxtBx.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FTtoMMTxtBx.Location = New System.Drawing.Point(132, 55)
        Me.FTtoMMTxtBx.Name = "FTtoMMTxtBx"
        Me.FTtoMMTxtBx.Size = New System.Drawing.Size(58, 20)
        Me.FTtoMMTxtBx.TabIndex = 10
        '
        'ClearBtn
        '
        Me.ClearBtn.BackColor = System.Drawing.SystemColors.Control
        Me.ClearBtn.FlatAppearance.BorderColor = System.Drawing.Color.Red
        Me.ClearBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkRed
        Me.ClearBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkRed
        Me.ClearBtn.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.ClearBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClearBtn.Location = New System.Drawing.Point(132, 94)
        Me.ClearBtn.Name = "ClearBtn"
        Me.ClearBtn.Size = New System.Drawing.Size(59, 19)
        Me.ClearBtn.TabIndex = 16
        Me.ClearBtn.Text = "Clear"
        Me.ClearBtn.UseVisualStyleBackColor = False
        '
        'USDText
        '
        Me.USDText.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.USDText.Location = New System.Drawing.Point(68, 94)
        Me.USDText.Name = "USDText"
        Me.USDText.Size = New System.Drawing.Size(58, 20)
        Me.USDText.TabIndex = 17
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(68, 78)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "CAD-USD"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 78)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 13)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "EXGRATE"
        '
        'CalcTxtBx
        '
        Me.CalcTxtBx.Location = New System.Drawing.Point(4, 5)
        Me.CalcTxtBx.Name = "CalcTxtBx"
        Me.CalcTxtBx.ReadOnly = True
        Me.CalcTxtBx.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CalcTxtBx.Size = New System.Drawing.Size(196, 20)
        Me.CalcTxtBx.TabIndex = 19
        Me.CalcTxtBx.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'MiniCalc
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(204, 151)
        Me.ContextMenuStrip = Me.ContextMenuStrip1
        Me.Controls.Add(Me.CalcTxtBx)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(220, 190)
        Me.MinimumSize = New System.Drawing.Size(220, 190)
        Me.Name = "MiniCalc"
        Me.Text = "MiniCalc"
        Me.TopMost = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents MMtoFtTxtBx As System.Windows.Forms.TextBox
    Friend WithEvents MMtoFtLabel As System.Windows.Forms.Label
    Friend WithEvents INtoFtTxtBx As System.Windows.Forms.TextBox
    Friend WithEvents FTtoINTxtBx As System.Windows.Forms.TextBox
    Friend WithEvents FtTOIN As System.Windows.Forms.Label
    Friend WithEvents InchestoFtLabel As System.Windows.Forms.Label
    Friend WithEvents MMtoINTxtBx As System.Windows.Forms.TextBox
    Friend WithEvents MMtoInchesLabel As System.Windows.Forms.Label
    Friend WithEvents INtoMMLabel As System.Windows.Forms.Label
    Friend WithEvents INtoMMTxtBx As System.Windows.Forms.TextBox
    Friend WithEvents FtToMM As System.Windows.Forms.Label
    Friend WithEvents FTtoMMTxtBx As System.Windows.Forms.TextBox
    Friend WithEvents ClearBtn As System.Windows.Forms.Button
    Friend WithEvents CalcTxtBx As System.Windows.Forms.TextBox
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents AlwaysOnTopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents USDText As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ExgRtText As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label

End Class
